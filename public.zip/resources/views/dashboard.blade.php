@extends('app')

@section('content')


<div class="container">
  <h1>User List</h1>          
        <a class="btn btn-primary" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            Logout
        </a>

        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
            @csrf
        </form>
  <table class="table table-striped">
    <thead>
      <tr>
        <th>User Profile</th>
        <th>Name</th>
        <th>Description</th>
      </tr>
    </thead>
    <tbody>
        @foreach($users as $user)
            <tr>
                <td><img src="{{ asset('storage/' . $user->image) }}" alt="User Image" width="100"></td>
                <td>{{$user->name}}</td>
                <td>{{$user->description}}</td>
                <td>
                    <a href="{{ route('users.edit', $user->id) }}"class="btn btn-primary">Edit</a>
                    <a href="{{ route('users.view', $user->id) }}" class="btn btn-success">View</a>
                    
                    <form method="POST" action="{{ route('users.destroy', $user->id) }}" style="display: inline-block;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
        @endforeach
    </tbody>
  </table>
  {{ $users->links() }}
</div>
@endsection