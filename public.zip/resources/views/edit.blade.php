@extends('app')

@section('content')
<div class="container">
        <div class="row">
            <div class="col-md-6">
            <h1>Edit User</h1>
            <form method="POST" action="{{ route('users.update', $user->id) }}">
                @csrf
                @method('PUT')
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input class="form-control" type="text" name="name" value="{{ $user->name }}" required>
                </div>
                    
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input class="form-control" type="email" name="email" value="{{ $user->email }}" required>
                </div>
                    
                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea class="form-control" name="description" rows="4">{{ $user->description }}</textarea>
                </div>
                    
                <div class="form-group">
                    <button type="submit">Update</button>
                </div>
            </form>
            </div>
        </div>
    </div>

@endsection
