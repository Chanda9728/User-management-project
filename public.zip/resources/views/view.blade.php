@extends('app')

@section('content')
<div class="container">
        <div class="row">
            <div class="col-md-6">
            <h1>User Details</h1>
            <form>
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input class="form-control" type="text" name="name" value="{{ $user->name }}" required>
                </div>
                    
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input class="form-control" type="email" name="email" value="{{ $user->email }}" required>
                </div>
                    
                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea class="form-control" name="description" rows="4">{{ $user->description }}</textarea>
                </div>
            </form>
            </div>
        </div>
    </div>

@endsection
