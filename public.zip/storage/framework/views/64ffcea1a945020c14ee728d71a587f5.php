

<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="row">
            <div class="col-md-6">
            <h1>User Details</h1>
            <form>
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input class="form-control" type="text" name="name" value="<?php echo e($user->name); ?>" required>
                </div>
                    
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input class="form-control" type="email" name="email" value="<?php echo e($user->email); ?>" required>
                </div>
                    
                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea class="form-control" name="description" rows="4"><?php echo e($user->description); ?></textarea>
                </div>
            </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp8.1\htdocs\demo-project\UserManager\resources\views/view.blade.php ENDPATH**/ ?>