

<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="row">
            <div class="col-md-6">
            <h1>Edit User</h1>
            <form method="POST" action="<?php echo e(route('users.update', $user->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input class="form-control" type="text" name="name" value="<?php echo e($user->name); ?>" required>
                </div>
                    
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input class="form-control" type="email" name="email" value="<?php echo e($user->email); ?>" required>
                </div>
                    
                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea class="form-control" name="description" rows="4"><?php echo e($user->description); ?></textarea>
                </div>
                    
                <div class="form-group">
                    <button type="submit">Update</button>
                </div>
            </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp8.1\htdocs\demo-project\UserManager\resources\views/edit.blade.php ENDPATH**/ ?>