

<?php $__env->startSection('content'); ?>


<div class="container">
  <h1>User List</h1>          
        <a class="btn btn-primary" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            Logout
        </a>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
  <table class="table table-striped">
    <thead>
      <tr>
        <th>User Profile</th>
        <th>Name</th>
        <th>Description</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><img src="<?php echo e(asset('storage/' . $user->image)); ?>" alt="User Image" width="100"></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->description); ?></td>
                <td>
                    <a href="<?php echo e(route('users.edit', $user->id)); ?>"class="btn btn-primary">Edit</a>
                    <a href="<?php echo e(route('users.view', $user->id)); ?>" class="btn btn-success">View</a>
                    
                    <form method="POST" action="<?php echo e(route('users.destroy', $user->id)); ?>" style="display: inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php echo e($users->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp8.1\htdocs\demo-project\UserManager\resources\views/dashboard.blade.php ENDPATH**/ ?>